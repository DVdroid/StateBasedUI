# VAStateBasedUIUpdates
Demo iOS project to make a sudo network call, parse data and update UI but all this using state based UI update approach.
