//
//  RootViewController.swift
//  VAStateBasedUIUpdates
//
//  Created by Vikash Anand on 07/03/20.
//  Copyright © 2020 Vikash Anand. All rights reserved.
//

import UIKit

final class RootViewController: UIViewController {
    
    private var spinnerView: SpinnerView?
    private var employeeTableView: EmployeeTableView?
    private var noConnectionView: NoConnectionView?
    private var noDataFoundView: NoDataFoundView?
    
    private var viewModel = MemeberViewModel(NetworkFetcher())
    private var members: [Member]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "Members"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Reload",
                                                                 style: .done,
                                                                 target: self,
                                                                 action: #selector(reload))
        self.loadMembers()
    }
    
    @objc private func reload() {
        self.loadMembers()
    }
    private var isRefreshBarButtonItemEnabled: Bool = false {
        didSet {
            self.navigationItem.rightBarButtonItem?.isEnabled = isRefreshBarButtonItemEnabled
        }
    }
    
    @objc private func refreshData() {
        self.isRefreshBarButtonItemEnabled = false
        self.loadMembers()
    }
    
    private func loadMembers() {
        
        self.isRefreshBarButtonItemEnabled = false
        self.addSpinnerViewAsSubView(inView: self.view)
        
        viewModel.getMembers { (result: Result<MemberResponse, DataFetchError>) in
            
            self.removeSpinnerViewAsSubView()
            switch result {
                
            case .success(let memberResponse):
                guard let members = memberResponse.results else { return }
                self.isRefreshBarButtonItemEnabled = true
                self.members = members.filteredMaleMembers
                
                self.removeNoDataFoundViewAsSubView()
                self.removeNoConnectionViewAsSubView()
                
                self.addEmployeeTableViewAsSubView(inView: self.view)
                self.employeeTableView?.reloadData()
                
            case .failure(let error):
                self.removeTableViewAsSubView()
                switch error {
                case .noInternet:
                    self.addNoConnectionViewAsSubView(inView: self.view)
                case .noRecords, .badResponse:
                    self.addNoDataFoundViewAsSubView(inView: self.view)
                default:
                    print("Error: \(String(describing:error.errorDescription))")
                }
            }
        }
    }
    
    @objc private func retry() {
        loadMembers()
    }
}

extension RootViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        guard let members = self.members else { return cell }
        guard let member = members.first else { return cell }
        cell.textLabel?.text = Value(at: indexPath, from: member)?.title
        
        return cell
    }
}


private enum Value {
    case firstName(from: Member)
    case lastName(from: Member)
    case emailName(from: Member)
    case genderName(from: Member)
    
    var title: String {
        switch self {
        case .firstName(let member):
            return member.name?.first ?? ""
        case .lastName(let member):
            return member.name?.last ?? ""
        case .emailName(let member):
            return member.email ?? ""
        case .genderName(let member):
            return member.gender ?? ""
        }
    }
}

extension Value {
    
    init?(at indexPath: IndexPath, from member: Member) {
        
        switch indexPath.row {
        case 0:
            self = .firstName(from: member)
        case 1:
            self = .lastName(from: member)
        case 2:
            self = .emailName(from: member)
        case 3:
            self = .genderName(from: member)
        default:
            fatalError("Invalid index path")
        }
    }
}


extension RootViewController {
    
    func addSpinnerViewAsSubView(inView parentView: UIView) {
        if self.spinnerView == nil { self.spinnerView = SpinnerView() }
        self.spinnerView?.showSpinner(inView: parentView)
    }
    
    func removeSpinnerViewAsSubView() {
        self.spinnerView?.removeSpinner()
    }
    
    func addEmployeeTableViewAsSubView(inView parentView: UIView) {
        if self.employeeTableView == nil {
            self.employeeTableView = EmployeeTableView(frame: .zero, style: .plain)
            self.employeeTableView?.dataSource = self
        }
        self.employeeTableView?.showEmployeeTableView(inView: parentView)
    }
    
    func removeTableViewAsSubView() {
        self.employeeTableView?.removeEmployeeTableView()
    }
    
    func addNoConnectionViewAsSubView(inView parentView: UIView) {
        if self.noConnectionView == nil { self.noConnectionView = NoConnectionView(retryAction: self.retry) }
        self.noConnectionView?.showNoConnectionView(inView: parentView)
    }
    
    func removeNoConnectionViewAsSubView() {
        self.noConnectionView?.removeNoConnectionView()
    }
    
    func addNoDataFoundViewAsSubView(inView parentView: UIView) {
        if self.noDataFoundView == nil { self.noDataFoundView = NoDataFoundView(retryAction: self.retry) }
        self.noDataFoundView?.showNoDataFoundView(inView: parentView)
    }
    
    func removeNoDataFoundViewAsSubView() {
        self.noDataFoundView?.removeNoDataFoundView()
    }
}
